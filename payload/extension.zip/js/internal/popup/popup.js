/* let superlemon_base_url = "https://dev-api-ss-integration.gupshup.io";
let whatsapp_base_url = "https://web.whatsapp.com";
let superlemon_domain = "gupshup.io";
let whatsapp_domain = "whatsapp.com"; */
//let cookieKey = "access_token"; 

$(function () {
  console.log("Popup");

  init();
  registerListeners();
});

function init() {
  checkLogin();
}

function checkLogin() {

  chrome.runtime.sendMessage(
    {
      type: "login-query",
    },
    (response) => {
      console.log("login Request Sent", response);
      toggleLoginUI(response);
    }
  );

}

function isValidShopName() {
  let shopName = getShopName();
  if (!shopName || shopName.includes("/")) {
    handleLoginError({ message: "Please Enter a Valid ShopId to Proceed" });
    return false;
  }
  return true;
}


function handleLoginError(error) {
  try {
    if (error.message) {
      showLoginErrorMessage(error.message);
      setTimeout(() => {
        cleanLoginErrorMessage();
      }, ERROR_MSG_TIMEOUT);
    }
  } catch (err) {
    console.log(err);
  }
}

function showLoginErrorMessage(message) {
  $("#login-error-area").removeClass("sl-hidden");
  $("#login-error-area").html(message);
}

function cleanLoginErrorMessage() {
  $("#login-error-area").html("");
  $("#login-error-area").addClass("sl-hidden");
}


function getShopName() {
  let shopName = $("#shop-name").val();
  if (shopName) {
    shopName = shopName.trim().replaceAll("https://", '').replaceAll("http://", '');
    if (shopName.endsWith("/")) {
      shopName = shopName.substring(0, shopName.length - 1);
    }
  }
  return shopName;
}

/* function logout() {
  cleanLocalStorage(() => {
    removeCookie(superlemon_base_url, cookieKey, () => {
      toggleLoginUI(false);
    });
  });
} */

function toggleLoginUI(isLoggedIn) {
  if (isLoggedIn) {
    $("#login-div").hide();
    $("#logout-div").show();
    populateShopName();
  } else {
    $("#login-div").show();
    $("#logout-div").hide();
  }
}

function populateApikey() {
  getFromLocalStorage(cookieKey, (val) => {
    $("#apikey").val(val);
  });
}

function populateShopName() {
  getFromLocalStorage(cookieKey, (apikey) => {
    getShopDetails((response, error) => {
      if (!error) {
        $("#apikey").val(response.shop.name);
      }
    }, apikey);
  });
}

function getShopDetails(callback, apikey) {
  var settings = {
    url: superlemon_account_base_url + "/account/v1/shop",
    method: "GET",
    headers: {
      token: apikey,
    },
  };
  makeApiCall(settings, callback);
}

function makeApiCall(settings, callback) {
  $.ajax(settings)
    .done((response) => {
      if (callback) {
        callback(response, null);
      }
    })
    .fail((response) => {
      if (callback) {
        callback(null, new Error("Unable to Get Response"));
      }
    });
}


function getFromLocalStorage(key, onLoad) {
  chrome.storage.local.get([key], function (result) {
    if (onLoad) {
      onLoad(result ? result[key] : null);
    }
  });
}

function registerListeners() {
  document.getElementById("login-btn").addEventListener("click", () => {
    if (isValidShopName()) {
      var url = superlemon_account_base_url + "/account/oauth/shopify?shop=" + getShopName();
			var loginWindow = window.open(
				url,
				"_blank",
				"toolbar=no,scrollable=no,left=100,width=600,height=600"
			);
      chrome.runtime.sendMessage(
        {
          type: "login-query",
          checkInterval: true,
        },
        (response) => {
          console.log("login Request Sent sssss", response);
        }
      );
    }
  });

  function saveInLocalStorage(key, value) {
    localStorage.setItem(key, value);
  }

  function saveInChromeLocalStorage(key, value) {
    let data = {};
    data[key] = value;
    console.log("saving " + JSON.stringify(data));
    chrome.storage.local.set(data);
  }
  document.getElementById("logout-btn").addEventListener("click", () => {
    chrome.runtime.sendMessage(
      { type: "logout-request", content: { shopId: "abcd" } },
      (response) => {
        console.log("logout Request Sent", response);
      }
    );
  });

  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    sendResponse();
    if (message && message.type) {
      switch (message.type) {
        case "login-request":
          toggleLoginUI(message.status);
          break;
        case "logout-request":
          toggleLoginUI(!message.status);
          console.log("Need to complete logout code " + message);
          break;
        case "login-query":
          toggleLoginUI(message.status);
          break;
      }
    }
  });
}

function handleError(error) {
  try {
    if (error.message) {
      showErrorMessage(error.message);
      setTimeout(() => {
        cleanErrorMessage();
      }, ERROR_MSG_TIMEOUT);
    }
  } catch (err) {
    console.log(err);
  }
}

function showErrorMessage(message) {
  $("#error-area").removeClass("sl-hidden");
  $("#error-area").html(message);
}

function cleanErrorMessage() {
  $("#error-area").html("");
  $("#error-area").addClass("sl-hidden");
}
