/**
 * injectScript - Inject internal script to available access to the `window`
 *
 * @param  {type} file_path Local path of the internal script.
 * @param  {type} tag The tag as string, where the script will be append (default: 'body').
 * @see    {@link http://stackoverflow.com/questions/20499994/access-window-variable-from-content-script}
 */
var data = [],
  res = [],
  userData,
  WAPI = {};
function injectScript(file_path, tag) {
  var node = document.getElementsByTagName(tag)[0];
  var script = document.createElement("script");
  script.setAttribute("type", "text/javascript");
  script.setAttribute("src", file_path);
  node.appendChild(script);
}

function injectCss(file_path, tag) {
  var node = document.getElementsByTagName(tag)[0];
  var css = document.createElement("link");
  css.setAttribute("type", "text/css");
  css.setAttribute("rel", "stylesheet");
  css.setAttribute("href", file_path);
  node.appendChild(css);
}
injectScript(chrome.runtime.getURL("js/internal/content.js"), "body");
/* injectScript(chrome.runtime.getURL("js/external/react.js"), "body");
injectScript(chrome.runtime.getURL("js/external/react-dom.js"), "body"); */

injectCss(chrome.runtime.getURL("css/external/fonts.css"), "body");

/* window.addEventListener("message", (e) => {
  if (e.data) {
    chrome.storage.local.set({ whatsappuserData: e.data }, function () {
      console.log("user is set to " + JSON.stringify(e.data));
    });
    if (e.data.type === "FROM_PAGE") {
      console.log("Received Data => ", e.data.text);
      userData = JSON.parse(e.data.text);
      //getData();
      console.log("here");
      add_html();
    } else if (e.data.type === "popup") {
      //getData();
      console.log("there");
      add_html();
    }
  }
}); */

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type == "popup_Js") {
    if (userData) {
      const elements = document.getElementsByClassName("grGJn");
      while (elements.length > 0) elements[0].remove();
      //getData();
      console.log("somewhere");
      add_html();
    }
  }
});
/*
function add_html() {
  chrome.storage.local.get("whatsappuserData", function (result) {
    loadHtml(JSON.parse(result.whatsappuserData.text));
  });
}
function loadHtml(user_data) {
  let ownerData = window.localStorage.getItem("last-wid");
  let ownerNumber = ownerData.split("@")[0].split('"')[1];
  console.log(
    "userdata",
    user_data,
    user_data.phoneNumber,
    "owner data",
    ownerNumber
  );
  console.log("load adasd");
  var checkPageButton1 = document.querySelectorAll("header")[1].children[1];
  console.log("checkbutton", checkPageButton1);
  let api =
    "https://dev-wa-ss-integration.gupshup.io/account/v1/data/" +
    ownerNumber +
    "/user/" +
    userData.phoneNumber;
  checkPageButton1.addEventListener(
    "click",
    function () {
      console.log("clicked");
      $.ajax({
        type: "GET",
        url: api,

        success: function (result) {
          //$("#more").after(html);
          if (result) {
            create_html();
            console.log("success", result);
          }
        },
        error: function (result) {
          //$("#more").after(html);
          console.log("error", result);
        },
      });
    },
    false
  );
}
function create_html() {
  console.log("create_html");
  var div_form = "";
  let form = "";
  form += `<div id="profile_html" style="background-color: white; border: 1px solid;">
    <div class="d-flex" style="width:300px; height: 200px;">
    <div id="close" style="text-align:right;">
    X
    </div>
    <div style="text-align:center;">
    testing profile html
    </div>
    </div>
    </div>`;
  div_form = document.createElement("DIV");
  div_form.style.position = "fixed";
  div_form.style.top = "20%";
  div_form.style.left = "70%";
  div_form.style.textAlign = "right";
  div_form.style.zIndex = "1000000";
  div_form.innerHTML = form;
  document.body.appendChild(div_form);

  let close_button = document.getElementById("close");
  console.log("button", close_button);
  close_button.addEventListener("click", function () {
    console.log("close button clicked");
    div_form.innerHTML = "";
    document.body.appendChild(div_form);
    // div_form.style.display = "none"
  });

  var profile_tag = document.querySelectorAll("section")[0];
  html_tag = document.createElement("DIV");
  html_tag.style.zIndex = "5";
  html_tag.style.textAlign = "center";
  html_tag.innerHTML = form;
  profile_tag.insertBefore(html_tag, profile_tag.firstChild);
}
 */
/* function getData() {
  chrome.storage.local.get("whatssuggest", function (result) {
    console.log("Value currently is " + result.whatssuggest);
    if (result.whatssuggest) {
      res = result.whatssuggest;
    }
    chrome.storage.local.get("whatsappforms", function (result) {
      console.log("Value currently is " + JSON.stringify(result.whatsappforms));
      if (result.whatsappforms) {
        // result.whatsappforms.forEach((form) => {
        //     data.push(form)
        // })
        data = res.concat(result.whatsappforms);
      }
      addsuggestion();
    });
  });
} */

/* function addsuggestion() {
  add_html();
  var suggestions = "";
  console.log("Add suggestion => ", data);
  data.map((item) => {
    suggestions += `<button style="background-color: #eeeeee;
margin: 5px;
padding: 5px 10px;
font-size: inherit;
border-radius: 50px;" class="reply-options">${item.name}
<span style="display: none">${
      item.file ? item.val : item.text
    }</span></button>`;
  });
  var div = document.createElement("DIV");
  div.style.textAlign = "center";
  div.style.zIndex = "5";
  div.innerHTML = suggestions;
  div.classList.add("grGJn");
  var mainDiv = document.querySelector("#main");
  var footer = document.querySelector("footer");
  footer.insertBefore(div, footer.firstChild);
  var suggestions = document.body.querySelectorAll(".reply-options");
  for (let i = 0; i < suggestions.length; i++) {
    const suggestion = suggestions[i];
    suggestion.addEventListener("click", (event) => {
      console.log(event.target.lastChild.textContent);
      let text = event.target.lastChild.textContent;
      if (text.includes("base64")) {
        // sendImage(text, userData.serialized, 'testing', '', '');
        const d = {
          img: text,
          id: userData.serialized,
        };
        window.postMessage(
          { type: "Send_Image", text: `${JSON.stringify(d)}` },
          "*"
        );
      } else {
        console.log("user data ==>", userData);
        text = text.replaceAll("%name", userData.ContactName);
        text = text.replaceAll("%mobile", userData.phoneNumber);
        text = text.replaceAll("%wname", userData.WAName);
        text = text.replaceAll("%greeting", userData.Greetings);
        messageBox = document.querySelectorAll("[contenteditable='true']")[1];
        message = text;
        event = document.createEvent("UIEvents");
        messageBox.innerHTML = message; // test it
        event.initUIEvent("input", true, true, window, 1);
        messageBox.dispatchEvent(event);
      }
      // eventFire(document.querySelector('span[data-icon="send"]'), 'click');
    });
  }
  mainDiv.children[mainDiv.children.length - 5].querySelector(
    "div > div div[tabindex]"
  ).scrollTop += 100;
} */

// window.addEventListener("message", (e) => {
//     if (e.data) {
//         console.log("LOAD HTML")
//         if (e.data.type === "LOAD_HTML") {
//             loadHtml(JSON.parse(e.data.text))
//         }
//     }
// });

// document.addEventListener('DOMContentLoaded', function() {
/*  var checkPageButton = document.querySelectorAll("header")[1].firstChild;
  console.log("checkbutton", checkPageButton); */
// to get profile section
// document.querySelectorAll("section")[0].firstChild

/*  checkPageButton.addEventListener(
    "click",
    function () {
      console.log("clicked");
      $.ajax({
        type: "GET",
        url: api,

        success: function (result) {
          //$("#more").after(html);
          if (result) {
            create_html();
            console.log("success", result);
          }
        },
        error: function (result) {
          //$("#more").after(html);
          console.log("error", result);
        },
      });
    },
    false
  ); */
//   }, false);
