let eventQ = [];
let interval;
let isPageLoadComplete = false;
let shopDetails;
const DEFAULT_TIMEOUT = 3000;
const ERROR_MSG_TIMEOUT = 10000;
const POLL_TIMEOUT = 3 * 60 * 1000; //3 min
const PAGESIZE = 10;
let logResponse = false;
let skipPreview = false;
let shouldPoll = false;
var allorderpage = 0;
var allabandonorderpage = 0;
let totalOrder = 0;
let totlaAbandonOrder = 0;
let isMoreAllOrderAvailble = true;
let isMoreABOrderAvailble = true;
let isUserSpecificOpenOrderAvailable = false;
let isUserSpecificCheckoutOrderAvailable = false;
let isExtensionFeatureEnabled = false
let icons = {
  "sl-icon": chrome.runtime.getURL("icons/sl-extension-icon.png"),
  "all-order-icon": chrome.runtime.getURL("icons/order-light.png"),
  "all-order-dark-icon": chrome.runtime.getURL("icons/order-dark.png"),
  "user-icon": chrome.runtime.getURL("icons/user-light.png"),
  "user-dark-icon": chrome.runtime.getURL("icons/user-dark.png"),
  "sl-banner-icon": chrome.runtime.getURL("icons/sl-banner-icon.png"),
  "left-arrow-icon": chrome.runtime.getURL("icons/left-arrow.png"),
  "logout-icon": chrome.runtime.getURL("icons/logout.png"),
  "collapse-icon": chrome.runtime.getURL("icons/collapse.png"),
  "expand-icon": chrome.runtime.getURL("icons/expand.png"),
  "cart-light-icon": chrome.runtime.getURL("icons/cart-light.png"),
  "cart-dark-icon": chrome.runtime.getURL("icons/cart-dark.png"),
  "settings-icon": chrome.runtime.getURL("icons/settings-light.png"),
  "settings-dark-icon": chrome.runtime.getURL("icons/settings-dark.png"),
  "logout-icon": chrome.runtime.getURL("icons/logout-light.png"),
  "logout-dark-icon": chrome.runtime.getURL("icons/logout-light.png"),
};
let port;

let assets = {
  orderCard: {
    path: "html/order-card.html",
  },
  navbar: {
    path: "html/navbar.html",
  },
  orderCounter: {
    path: "html/order-counter.html",
  },
  checkoutCounter: {
    path: "html/checkout-counter.html",
  },
  container: {
    path: "html/container.html",
  },
  userDetails: {
    path: "html/user-details.html",
  },
  loginCard: {
    path: "html/login.html",
  },
  templates: {
    path: "html/templates.html",
  },
  orderHistory: {
    path: "html/order-history.html",
  },
  singleTemplateElement: {
    path: "html/single-template-element.html",
  },
  templateRowElement: {
    path: "html/template-row-element.html",
  },
  templateAction: {
    path: "html/template-action.html",
  },
  clearTagAction: {
    path: "html/clear-tag-action.html",
  },
  singleLineItem: {
    path: "html/single-line-item.html",
  },
  abCartCard: {
    path: "html/ab-cart-card.html",
  },
  settings: {
    path: "html/settings.html",
  },
  navbarBottom: {
    path: "html/bottom-navbar.html",
  },
  tagItem: {
    path: "html/tags-item.html",
  },
  setting: {
    path: "html/setting.html",
  },
  removeTag: {
    path: "html/remove-tag-action.html",
  },
  languageItem: {
    path: "html/language-list-item.html",
  },
};

//// Need to Check /////

function simulateTextBoxEntry(charCode) {
  $("._2_1wd.copyable-text.selectable-text").trigger({
    type: "keypress",
    keyCode: charCode,
    which: charCode,
    charCode: charCode,
  });
}

/////////////////////////////////////// ON CLICK ACTIONS ////////////////////////////////

function attemptLogin() {
  if (isValidShopName()) {
    port.postMessage({
      type: "login-request",
      content: { shop: getShopName() },
    });
  }
}

function isValidShopName() {
  let shopName = getShopName();
  if (!shopName || shopName.includes("/")) {
    handleLoginError({ message: "Please Enter a valid ShopId to Proceed" });
    return false;
  }
  return true;
}

function handleLoginError(error) {
  try {
    if (error.message) {
      showLoginErrorMessage(error.message);
      setTimeout(() => {
        cleanLoginErrorMessage();
      }, ERROR_MSG_TIMEOUT);
    }
  } catch (err) {
    // console.log(err);
  }
}

function showLoginErrorMessage(message) {
  $("#login-error-area").removeClass("sl-hidden");
  $("#login-error-area").html(message);
}

function cleanLoginErrorMessage() {
  $("#login-error-area").html("");
  $("#login-error-area").addClass("sl-hidden");
}

function attemptLogout() {
  port.postMessage({
    type: "logout-request",
    content: { shop: getShopName() },
  });
  location.reload();
}

function getShopName() {
  let shopName = $("#shop-name").val();
  if (shopName) {
    shopName = shopName
      .trim()
      .replaceAll("https://", "")
      .replaceAll("http://", "");
    if (shopName.endsWith("/")) {
      shopName = shopName.substring(0, shopName.length - 1);
    }
  }
  return shopName;
}

function loadOrders() {
  loadDataFromStorage(storeClientKey, (user) => {
    console.log(user, storeClientKey);
    $("#user-specific-oreder-error-area").addClass("sl-hidden");

    getTemplates((templateResponse, error) => {
      let templates = [];
      if (templateResponse && templateResponse.templates) {
        templates = templateResponse.templates;
        renderTemplates(templates);
        registerQuickReplyClickListeners();
      }
      if (user) {
        console.log("Loading for " + user.phone);
        getOrdersForPhone(user.phone, templates);
        getCheckoutsForPhone(user.phone, templates);
      } else {
        $("#user-specific-oreder-error-area").removeClass("sl-hidden");
        console.log("-------------No User Selected----------");
      }
    });
  });
}

function getCheckoutsForPhone(phone, templates) {
  if (!phone) {
    return;
  }

  renderCounters("#sl-user-abcart-count", 1, 1);
  getCheckouts(phone, (response, error) => {
    $("#user-specific-abcart-div").html("");
    if (response && response.checkouts && response.checkouts.length > 0) {
      isUserSpecificCheckoutOrderAvailable = true;
      let checkouts = response.checkouts;
      let i = 1;
      checkouts.forEach((checkout) => {
        renderCheckout(checkout, i);
        i++;
      });
      if (phone) {
        showOrderAction();
        toggleUserOrderDataDiv(true);
      }
      renderCounters("#sl-user-abcart-count", 1, checkouts.length);
      renderApplicableTemplates(templates);
      registerCardActionListeners();
    } else {
      // if(!isUserSpecificCheckoutOrderAvailable && !isUserSpecificCheckoutOrderAvailable){
      //   console.log("-----------Show------------")
      // }
      renderCounters("#sl-user-abcart-count", 0, 0);
    }
  });
}

function renderCounters(selector, current, max) {
  $(selector).data("current", current);
  if (typeof max === "number") {
    $(selector).data("max", max);
  }
  $(selector).html(
    $(selector).data("current") + " / " + $(selector).data("max")
  );
}
function getAllAbandonedOrders() {
  getTemplates((templateResponse, error) => {
    console.log(templateResponse);
    let templates = [];
    if (templateResponse && templateResponse.templates) {
      templates = templateResponse.templates;
    }
    getAllAbandonedOrder((response, error) => {
      console.log(response);
      // clearOlderDiv(!phone);
      if (response && response.checkouts && response.checkouts.length > 0) {
        isMoreABOrderAvailble = true;

        let checkouts = response.checkouts;
        let i = 1;
        checkouts.forEach((checkout) => {
          renderAbandoneOrder(checkout, i);
          i++;
        });

        renderApplicableTemplates(templates);
        registerCardActionListeners();
        registerAbCardListeners();
      } else {
        isMoreABOrderAvailble = false;
        $("#abcart-checkout-order-holder").append(
          `<p class="flex justify-center w-full">No More Order!</p>`
        );
      }
    });
  });
}
function registerAbCardListeners() {
  $(".sl-clickable-order-div").off("click").on("click", (event) => {
    let contact = $(event.target).parents(".sl-order-cards").attr("contact");
    console.log(contact);
    if (contact) {
      window.location = "/send?phone=+" + contact;
    } else {
      handleError({ message: "No Phone Number Associated with the Order" });
    }
  });
}
function renderAbandoneOrder(checkoutData, index) {
  checkoutData.status = checkoutData.status.toLowerCase();
  processReadableAddress(checkoutData);
  processOrderItems(checkoutData);
  checkoutData["encoded-payload"] = encodePayload(JSON.stringify(checkoutData));
  checkoutData.createdOn = new Date(checkoutData.createdOn).toLocaleDateString(
    "en-US",
    { year: "numeric", month: "long", day: "numeric" }
  );
  checkoutData["hide-div"] = "sl-hidden";
  checkoutData["sl-clickable"] = "sl-clickable-order-div";

  checkoutData["card-index"] = index;
  checkoutData["can-hide"] = "";
  checkoutData["customerName"] = checkoutData["customerName"] || "";
  processLineItems(checkoutData);

  if (!checkoutData.phone) {
    checkoutData.phone = "";
  }

  // $("#user-specific-abcart-div").append(
  //   populateTemplateUsingJSON(checkoutData, assets.abCartCard.content)
  // );
  $("#abcart-checkout-order-holder").append(
    populateTemplateUsingJSON(checkoutData, assets.abCartCard.content, true)
  );
}
function getOrdersForPhone(phone, templates, temp) {
  console.log("===============>", temp);
  console.log(phone);
  if (phone) {
    getOrdersForPhoneInternal(phone, templates);
    renderCounters("#sl-user-order-count", 1, 1);
  } else {
    getTemplates((templateResponse, error) => {
      console.log(templateResponse);
      let templates = [];
      if (templateResponse && templateResponse.templates) {
        templates = templateResponse.templates;
        renderTemplates(templates);
        registerQuickReplyClickListeners();
      }
      populateOrderDetails({}, () => {
        console.log("Order Count Updated");
      });
      getOrdersForPhoneInternal(phone, templates);
    });
  }
}

function getOrdersForPhoneInternal(phone, templates) {
  // console.log(phone);
  getOrders(phone, (response, error) => {
    // console.log(response);
    clearOlderDiv(!phone);
    if (response && response.orders && response.orders.length > 0) {
      isUserSpecificOpenOrderAvailable = true;
      if (phone) {
        toggleUserOrderDataDiv(true);
      }
      isMoreAllOrderAvailble = true;
      let orders = response.orders;
      let isSet = false;
      let i = 1;

      getAllTags((r) => {
        orders.forEach((order) => {
          // console.log(order);
          if (!isSet && phone) {
            populateUserDetailsFromOrder(order);
            populateOrderHistory(phone);
            showOrderAction();
            isSet = true;
          }
          renderOrder(order, !phone, i, r.tags);
          renderApplicableTag(
            r.tags,
            "#order-tag-list-" + order.id + (!phone ? true : false).toString(),
            "forordercard",
            order.id,
            !phone
          );

          i++;
        });
        if (phone) {
          renderCounters("#sl-user-order-count", 1, orders.length);
        }
        registerOrderHandler(!phone ? true : false);
        renderApplicableTemplates(templates);
        registerCardActionListeners();
      });
    } else {
      isMoreAllOrderAvailble = false;
      $("#order-data-holder").append(
        `<p class="flex justify-center w-full">No More Order!</p>`
      );
      renderCounters("#sl-user-order-count", 0, 0);

      // if(!isUserSpecificCheckoutOrderAvailable && !isUserSpecificCheckoutOrderAvailable){
      //   console.log("-----------Show------------")
      // }
      if (phone) {
        toggleUserOrderDataDiv(false);
      }
    }
  });
}

function populateOrderHistory(phone) {
  getOrderHistory(phone, (response, error) => {
    if (response && response.history) {
      renderOrderHistory(response.history);
    }
  });
}

///////////////////////////////// ON PAGE LOAD ACTIONS ///////////////////////

preLoad(() => {
  console.log("Pre ------------- load")
  getTranslatedData((data) => {
    console.log(data)
    delete data.status
    localStorage.setItem("landata",JSON.stringify(data))
    registerForEvent();
    loadAllAssets(() => {
      if (isAssetLoadComplete()) {
        //assets.navbar.content = navbarContent;
        prepareSystem();
      }
    });
  })
  
});

function prepareSystem() {
  onPageLoad(() => {
    // userViewToggle(false);
    showAllOrder();
    isPageLoadComplete = true;
    dequeueAll();
  });
}

function isAssetLoadComplete() {
  let assetKeys = Object.keys(assets);
  for (let i = 0; i < assetKeys.length; i++) {
    // console.log("Checking for asset : " + assetKeys[i]);
    if (!assets[assetKeys[i]].content) {
      return false;
    }
  }
  return true;
}

function loadAllAssets(callback) {
  Object.keys(assets).forEach((assetKey) => {
    loadAsset(assetKey, callback);
  });
}

function loadAsset(assetKey, callback) {
  let settings = {
    url: chrome.runtime.getURL(assets[assetKey].path),
    method: "GET",
    timeout: DEFAULT_TIMEOUT,
  };
  makeApiCall(settings, (response, error) => {
    if (response) {
      console.log("Data Received for " + assetKey);
      // console.log(response);
      assets[assetKey].content = populateTemplateUsingJSON(
        icons,
        response,
        false
      );
    }
    callback();
  });
}

function loadDataFromStorage(key, onLoad) {
  chrome.storage.local.get([key], function (result) {
    if (onLoad) {
      onLoad(result ? result[key] : null);
    }
  });
}

function preLoad(onLoad) {
  loadDataFromStorage(cookieKey, (value) => {
    if (value) {
      saveInLocalStorage(cookieKey, value);
    } else {
      //remove from local storage
      removeFromLocalStorage(cookieKey);
    }
    if (onLoad) {
      onLoad();
    }
  });
}

function attemptDivAddition(onAdd) {
  // document.querySelectorAll("[contenteditable='true']")[0];
  // if (document.querySelector("._3QfZd")) {
  if (document.querySelector("[contenteditable='true']")) {
    addDiv();
    if (onAdd) {
      onAdd();
    }
  }
}

function onPageLoad(onLoadComplete) {
  let interval = setInterval(() => {
    console.log("Atempting To add");
    attemptDivAddition(() => {
      clearInterval(interval);

      registerNonLoginListeners();
      if (!isLoggedIn()) {
        showLoginDiv(true);
      } else {
        onLoginSuccess(onLoadComplete);
      }
    });
  }, 2000);
}

function registerNonLoginListeners() {
  port = chrome.runtime.connect({ name: "login-state" });
  port.onMessage.addListener(function (msg) {
    handleLoginLogOutAsync(msg);
  });
  port.onDisconnect.addListener(() => {
    //handle disconnect
    console.log('handled on disconnect')
    window.location.reload()
  });
  $("#login-btn").on("click", () => {
    attemptLogin();
  });
}

function postLoginAction(onLoadComplete) {
  loadShopData(() => {
    console.log("Order Count Load Compeleted");
    getOrdersForPhone();
    if (onLoadComplete) {
      onLoadComplete();
    }
  });
}

function getShopId(callback) {
  if (shopDetails && shopDetails.id) {
    return callback(shopDetails.id);
  }
  loadShopData(() => {
    return callback(shopDetails ? shopDetails.id : undefined);
  });
}

function loadShopData(callback) {
  getShopDetails((response, error) => {
    if (response) {
      shopDetails = response.shop;
      populateOrderDetails(shopDetails, callback);
    }
  });
}

function populateOrderDetails(shopDetails, callback) {
  getOrderCount((response, err) => {
    if (response) {
      totalOrder = response.count;
      addOrderCounter();
      setOrderCount(response.count);
      if (callback) {
        callback();
      }
    }
  });

  getAbOrderCount((response, err) => {
    if (response) {
      totlaAbandonOrder = response.count;
      addAbCounter();
      setAbOrderCount(response.count);
      // if (callback) {
      //   callback();
      // }
    }
  });
}

function onLoginSuccess(onLoadComplete) {
  console.log("onLogin Success");
  registerNavigationFunctions();
  showLoginDiv(false);
  postLoginAction(onLoadComplete);
  clearOlderDiv(false);
  toggleUserOrderDataDiv(false);
}

//////////////////////////////// RENDERING RELATED ///////////////////////////

function toggleUserOrderDataDiv(show) {
  if (show) {
    $("#user-fetchable-data-div").show();
  } else {
    $("#user-fetchable-data-div").hide();
  }
}

function renderOrderHistory(history) {
  $("#order-history").html(
    populateTemplateUsingJSON(history, assets.orderHistory.content, true)
  );
}

function setOrderCount(count) {
  $("#order-counter").html(count);
  adjustOrderCounterWidth(count, "#order-counter");
}
function setAbOrderCount(count) {
  $("#checkout-counter").html(count);
  adjustOrderCounterWidth(count, "#checkout-counter");
}

function addOrderCounter() {
  $("#order-counter-holder").html(assets.orderCounter.content);
}
function addAbCounter() {
  $("#checkout-counter-holder").html(assets.checkoutCounter.content);
}

function addDiv() {
  //$("._3QfZd.two")
  let appendWrapper = $($($("#app").children()[0]).children()[5]);
  appendWrapper.append(
    populateTemplateUsingJSON(
      {
        navbarContent: assets.navbar.content,
        bottomNavbarContent: assets.navbarBottom.content,
        loginContent: populateTemplateUsingJSON(
          {
            "header-class-for-darker-top-bar": $(
              $($(appendWrapper.children()[2]).children()[0]).children()[0]
            ).attr("class"),
          },
          assets.loginCard.content,
          true
        ),
        settingsContent: assets.settings.content,
        templates: assets.templates.content,
        "header-div-class": $(appendWrapper.children()[3]).attr("class") + '  main-extension-div',
        "header-internal-div-class": $(
          $(appendWrapper.children()[3]).children()[0]
        ).attr("class"),
      },
      assets.container.content,
      true
    )
  );
  console.log("Div Added");
}
/* 
function manupulateElementClickedState(selector, clicked, applyOnChildren, childSelector) {
  if ($(selector)) {
    if (clicked) {

      $(selector).addClass("sl-clickable-active");
    } else {
      $(selector).removeClass("sl-clickable-active");
    }
    if (applyOnChildren) {
      manpulateChildrenClickedState(selector, childSelector, clicked);
    }
  }
}

function manpulateChildrenClickedState(parentSelector, childSelector, clicked) {
  if ($(parentSelector)) {
    let children = $(parentSelector).children(childSelector);
    if (children) {
      for (let i = 0; i < children.length; i++) {
        let child = children[i];
        if (clicked) {
          $(child).addClass("sl-clickable-active");
        } else {
          $(child).removeClass("sl-clickable-active");
        }
      }
    }
  }
} */

function clearOlderDiv(global) {
  if (global) {
    // $("#order-data-holder").html("");
  } else {
    $("#user-specific-orders-div").html("");
    $("#user-details").html("");
    $("#order-history").html("");
  }
}

function renderOrder(orderData, global, index, tags) {
  // console.log(global);
  setOrderStatus(orderData);
  orderData.trackingNumber = orderData.trackingNumber
    ? orderData.trackingNumber
    : "-NA-";
  processOrderItems(orderData);
  processReadableAddress(orderData);
  orderData["encoded-payload"] = encodePayload(JSON.stringify(orderData));
  orderData.createdOn = new Date(orderData.createdOn).toLocaleDateString(
    "en-US",
    { year: "numeric", month: "long", day: "numeric" }
  );
  orderData["hide-div"] = global ? "sl-hidden" : "";
  orderData["sl-clickable"] = global ? "sl-clickable-order-div" : "";
  orderData["card-index"] = index;
  orderData["ids"] = orderData.id + (global ? true : false).toString();
  orderData["is_hide"] =
    localStorage.getItem("orderlayout") === "layout-1" ? "sl-hidden" : "";
  orderData["can-hide"] = global
    ? ""
    : index == 1
    ? "user-specific-order"
    : "sl-hidden user-specific-order";
  let i = tags.findIndex((p) => p.id === orderData.tagId);
  orderData["tags"] = i > -1 ? tags[i].name : "No Tag";
  orderData["customerName"] = orderData["customerName"] || "";
  setFulfillmentStatus(orderData);
  processLineItems(orderData);
  // console.log(orderData);
  if (!orderData.phone) {
    orderData.phone = "";
  }
  // console.log(orderData)
  if (global) {
    $("#order-data-holder").append(
      populateTemplateUsingJSON(orderData, assets.orderCard.content, true)
    );
  } else {
    $("#user-specific-orders-div").append(
      populateTemplateUsingJSON(orderData, assets.orderCard.content, true)
    );
  }
}

function setOrderStatus(order) {
  order.status = order.status
    .toLowerCase()
    .replaceAll("_", " ");

  switch (order.status) {
    case "user confirmed":
      order.status = "Cod Confirmed"
      break;
    case "user cancelled":
      order.status = "Cod Cancelled"
      break;
    default:
      break;
  }
}

function setFulfillmentStatus(order) {
  order.fulfillmentStatus = order.fulfillmentStatus
    .toLowerCase()
    .replaceAll("_", " ");
  return;

  order.fulfillmentStatus = "not fulfilled";

  switch (order.status) {
    case "confirmed":
    case "shipped":
    case "delayed":
      order.fulfillmentStatus = "partially fulfilled";
      break;
    case "fulfilled":
      order.fulfillmentStatus = "fulfilled";
      break;
  }
}

function processOrderItems(data) {
  try {
    if (data && data.details) {
      let orderItems = "";
      let items = JSON.parse(data.details);
      items.forEach((item) => {
        orderItems = orderItems + `${item.c} X ${item.p}` + "\n";
      });
      data.orderItems = orderItems;
    }
  } catch (err) {
    console.log("Unable to Process items", err);
  }
}

function processReadableAddress(data) {
  try {
    if (data && data.address) {
      let readableAddress = data.address.replaceAll("</br>", "\n");
      data.readableAddress = readableAddress;
    }
  } catch (err) {
    console.log("Unable to Process items", err);
  }
}

function renderCheckout(checkoutData, index) {
  checkoutData.status = checkoutData.status.toLowerCase();
  processReadableAddress(checkoutData);
  processOrderItems(checkoutData);
  checkoutData["encoded-payload"] = encodePayload(JSON.stringify(checkoutData));
  checkoutData.createdOn = new Date(checkoutData.createdOn).toLocaleDateString(
    "en-US",
    { year: "numeric", month: "long", day: "numeric" }
  );
  checkoutData["hide-div"] = "";
  checkoutData["sl-clickable"] = "";
  checkoutData["card-index"] = index;
  checkoutData["can-hide"] =
    index == 1 ? "user-specific-abcart" : "sl-hidden user-specific-abcart";
  checkoutData["customerName"] = checkoutData["customerName"] || "";

  processLineItems(checkoutData);

  if (!checkoutData.phone) {
    checkoutData.phone = "";
  }

  $("#user-specific-abcart-div").append(
    populateTemplateUsingJSON(checkoutData, assets.abCartCard.content, true)
  );
  // checkoutData["can-hide"]=""
  // $("#abcart-checkout-order-holder").append(
  //   populateTemplateUsingJSON(checkoutData, assets.abCartCard.content)
  // );
}

function processLineItems(orderData) {
  let lineItems = getAsJSON(orderData.details);
  let lineItemString = "";
  let hiddenLineItemString = "";
  let hideLineItemsDivClass = "sl-hidden";
  if (lineItems) {
    if (lineItems.length > 3) {
      hideLineItemsDivClass = "";
    }

    for (let i = 0; i < lineItems.length; i++) {
      let singleLineItem = populateTemplateUsingJSON(
        lineItems[i],
        assets.singleLineItem.content,
        true
      );
      if (i > 2) {
        hiddenLineItemString = hiddenLineItemString + singleLineItem;
      } else {
        lineItemString = lineItemString + singleLineItem;
      }
    }
  }
  orderData["lineItems"] = lineItemString;
  orderData["hiddenLineItems"] = hiddenLineItemString;
  orderData["hide-line-items-div"] = hideLineItemsDivClass;
}

function getAsJSON(elem) {
  try {
    return JSON.parse(elem);
  } catch (err) {
    return undefined;
  }
}

function showLoginDiv(state) {
  if (state) {
    $("#logged-in-div").hide();
    $("#login-div").show();
  } else {
    $("#logged-in-div").show();
    $("#login-div").hide();
  }
}

function showSettings(show) {
  if (show) {
    hideNonSettings();
    $("#all-checkout-div").show();
  } else {
    $("#all-checkout-div").hide();
  }
  //manupulateElementClickedState("#settings-selector", show, true, ".sl-navbar-text");
}

function hideNonSettings() {
  // To show abcart

  console.log("hiding anything other than settings");
  $("#user-specific-content-div").hide();
  $("#all-order-div").hide();
  $(".sl-color-invertable").removeClass("sl-navbar-dark");
  $("#abcart-selector").addClass("sl-navbar-dark");

  $(".sl-navbar-icon.order-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.order-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.user-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.user-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon-dark").removeClass("sl-hidden");
  $("#abcart-selector > .sl-navbar-text").addClass("navtext-color");
  $("#user-order-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#all-order-selector > .sl-navbar-text").removeClass("navtext-color");

  /*  manupulateElementClickedState("#all-order-selector", false, true, ".sl-navbar-text");
  manupulateElementClickedState("#user-order-selector", false, true, ".sl-navbar-text"); */
}

function userViewToggle(show) {
  showSettings(false);
  if (show) {
    // To Show user
    console.log("hiding global Content");
    $("#user-specific-content-div").show();
    $("#all-order-div").hide();
    $(".sl-color-invertable").removeClass("sl-navbar-dark");
    $("#user-order-selector").addClass("sl-navbar-dark");

    $(".sl-navbar-icon.order-icon").removeClass("sl-hidden");
    $(".sl-navbar-icon.order-icon-dark").addClass("sl-hidden");
    $(".sl-navbar-icon.user-icon").addClass("sl-hidden");
    $(".sl-navbar-icon.user-icon-dark").removeClass("sl-hidden");
    $(".sl-navbar-icon.cart-icon").removeClass("sl-hidden");
    $(".sl-navbar-icon.cart-icon-dark").addClass("sl-hidden");
    $("#abcart-selector > .sl-navbar-text").removeClass("navtext-color");
    $("#user-order-selector > .sl-navbar-text").addClass("navtext-color");
    $("#all-order-selector > .sl-navbar-text").removeClass("navtext-color");
  } else {
    console.log("hiding User Specific Content");
    $("#user-specific-content-div").hide();
    $("#all-order-div").show();
    shouldPoll = true;
    $(".sl-color-invertable").removeClass("sl-navbar-dark");
    $("#all-order-selector").addClass("sl-navbar-dark");

    $(".sl-navbar-icon.order-icon").addClass("sl-hidden");
    $(".sl-navbar-icon.order-icon-dark").removeClass("sl-hidden");
    $(".sl-navbar-icon.user-icon").removeClass("sl-hidden");
    $(".sl-navbar-icon.user-icon-dark").addClass("sl-hidden");
    $(".sl-navbar-icon.cart-icon").removeClass("sl-hidden");
    $(".sl-navbar-icon.cart-icon-dark").addClass("sl-hidden");
    $("#abcart-selector > .sl-navbar-text").removeClass("navtext-color");
    $("#all-order-selector > .sl-navbar-text").addClass("navtext-color");
    $("#user-order-selector > .sl-navbar-text").removeClass("navtext-color");
  }
  /*   manupulateElementClickedState("#all-order-selector", !show, true, ".sl-navbar-text");
  manupulateElementClickedState("#user-order-selector", show, true, ".sl-navbar-text"); */
}

function populateUserDetailsFromOrder(order) {
  $("#user-details").html(
    populateTemplateUsingJSON(order, assets.userDetails.content, true)
  );
}

function showOrderAction() {
  $("#user-specific-action-area").show();
}

function populateTemplateUsingJSON(json, stringTemplate, isLanguageTranslate) {
  // console.log(stringTemplate)

  const languageData = JSON.parse(localStorage.getItem("landata"));
  const temp = {
    ...json,
    ...languageData[
      localStorage.getItem("selected-language")
        ? localStorage.getItem("selected-language")
        : "English"
    ],
  };
  // console.log(temp,stringTemplate)
  Object.keys(temp).forEach((key) => {
    stringTemplate = stringTemplate.replaceAll("${" + key + "}", temp[key]);
    if (isLanguageTranslate) {
      stringTemplate = stringTemplate.replaceAll("@{" + key + "}", temp[key]);
    }
  });

  return populateIconsInTemplate(stringTemplate);
}

function populateIconsInTemplate(stringTemplate) {
  Object.keys(icons).forEach((key) => {
    stringTemplate = stringTemplate.replaceAll("${" + key + "}", icons[key]);
  });
  // console.log(stringTemplate);
  return stringTemplate;
}

function adjustOrderCounterWidth(count, selector) {
  if (count) {
    $(selector)
      .parent()
      .width("" + (5 + 5 * String(count).length));
  }
}

function renderTemplates(templates) {
  let length = templates.length;
  let allTemplateContent = "";
  let rowContent = "";
  for (let i = 0, j = 1; i < length; i++, j++) {
    // console.log(templates[i]);
    if (templates[i].category != "GREETING") {
      j--;
      continue;
    }
    if (!templates[i].active) {
      j--;
      continue;
    }

    rowContent =
      rowContent +
      populateTemplateUsingJSON(
        templates[i],
        assets.singleTemplateElement.content,
        true
      );
    if (j == 2) {
      allTemplateContent =
        allTemplateContent +
        populateTemplateUsingJSON(
          { templates: rowContent },
          assets.templateRowElement.content,
          true
        );
      rowContent = "";
      j = 0;
    }
  }
  if (rowContent) {
    allTemplateContent =
      allTemplateContent +
      populateTemplateUsingJSON(
        { templates: rowContent },
        assets.templateRowElement.content,
        true
      );
  }
  $("#list-template-div").html(allTemplateContent);
}

function renderApplicableTemplates(templates) {
  $(".template-li").html("");
  if (!templates) {
    return;
  }
  templates.forEach((template) => {
    if (template.category != "GREETING" && template.active) {
      $(".template-li").append(
        populateTemplateUsingJSON(template, assets.templateAction.content, true)
      );
    }
  });
}

function renderApplicableTag(tags, selector, type, orderid, phone = "") {
  $(selector).html("");
  if (!tags) {
    return;
  }

  if (type === "forsearch") {
    tags.forEach((tag) => {
      $(selector).append(
        populateTemplateUsingJSON(
          tag,
          populateTemplateUsingJSON(
            { order_id: orderid },
            assets.templateAction.content,
            true
          ),
          true
        )
      );
    });
    if ($("#all-order-filter-selected-tag").attr("tagId")) {
      $(selector).append(
        populateTemplateUsingJSON({}, assets.clearTagAction.content, true)
      );
    }

    $(selector)
      .off("click")
      .on("click", "li", function (event) {
        allorderpage = 0;

        $("#all-order-filter-selected-tag").attr(
          "tagId",
          $(this).attr("tagId")
        );
        getAllTags((r) => {
          renderApplicableTag(r.tags, "#all-order-filter-tag", "forsearch");
        });
        $("#order-data-holder").html("");
        getOrdersForPhone();
      });
  }
  if (type === "forordercard") {
    tags.forEach((tag) => {
      $(selector).append(
        populateTemplateUsingJSON(
          tag,
          populateTemplateUsingJSON(
            { order_id: orderid },
            assets.templateAction.content,
            true
          ),
          true
        )
      );
    });

    $(selector).append(
      populateTemplateUsingJSON(
        {
          order_id: orderid,
          ids: orderid + phone,
          isRemoveTagHide:
            $("#order-tag-" + orderid + phone).attr("tagid") === "0"
              ? "sl-hidden"
              : "",
        },
        assets.removeTag.content,
        true
      )
    );
    $(selector)
      .off("click")
      .on("click", "li", function (event) {
        if ($(this).attr("type") === "tag") {
          addTagToOrder($(this).attr("tagId"), $(this).attr("order-id"), () => {
            $("#order-tag-" + $(this).attr("order-id") + phone).html(
              $(this).attr("text")
            );
            $("#order-tag-" + $(this).attr("order-id") + phone).attr(
              "tagid",
              $(this).attr("tagId")
            );
            $("#remove-tag-" + $(this).attr("order-id") + phone).removeClass(
              "sl-hidden"
            );
          });
        } else {
          removeTagToOrder(
            $("#order-tag-" + orderid + phone).attr("tagid"),
            $(this).attr("order-id"),
            () => {
              $("#order-tag-" + $(this).attr("order-id") + phone).html(
                "No Tag"
              );
              $("#order-tag-" + $(this).attr("order-id") + phone).attr(
                "tagid",
                "0"
              );
              $("#remove-tag-" + $(this).attr("order-id") + phone).addClass(
                "sl-hidden"
              );
            }
          );
        }
      });
  }
}
/////////////////////////////// LISTENER RELEATED ////////////////////////////

function onMessageHandler(e) {
  if (e.data) {
    let content = {};
    if (e.data.type === "user-change") {
      content[storeClientKey] = e.data.user;
      chrome.storage.local.set(content, function () {
        console.log("user is set to " + JSON.stringify(e.data));
        console.log("Received Data => ", e.data.user);
        // userViewToggle(true);
        showUserOrder();
        loadOrders();
      });
    }
  }
}

function handleLoginLogOutAsync(message) {
  if (message && message.type) {
    switch (message.type) {
      case "login-request":
        if (message.status) {
          //prepareSystem();
          preLoad(() => {
            // userViewToggle();
            showAllOrder();
            onLoginSuccess(() => {
              console.log("post login action done");
            });
          });
        }
        break;
      case "logout-request":
        if (message.status) {
          showLoginDiv(true);
          removeFromLocalStorage(cookieKey);
        }
        break;
      case "login-query":
        break;
    }
  }
}
function showAbCart() {
  $("#all-checkout-div").show();
  $("#user-specific-content-div").hide();
  $("#all-order-div").hide();
  $("#settings-div").hide();

  $(".sl-color-invertable").removeClass("sl-navbar-dark");
  $("#abcart-selector").addClass("sl-navbar-dark");
  $(".sl-navbar-icon.order-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.order-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.user-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.user-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon-dark").removeClass("sl-hidden");
  $(".sl-navbar-icon.settings-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.settings-dark-icon").addClass("sl-hidden");

  $("#abcart-selector > .sl-navbar-text").addClass("navtext-color");
  $("#user-order-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#all-order-selector > .sl-navbar-text").removeClass("navtext-color");

  // $("#all-checkout-order-search")
  //   .off("change")
  //   .change(function () {
  //     getOrdersForPhone();
  //   });
  allabandonorderpage = 0;
  $("#all-abandon-order-search").val("");
  registerEventListenerForAllAbandonedOrder();
}
function showAllOrder() {
  $("#all-checkout-div").hide();
  $("#user-specific-content-div").hide();
  $("#all-order-div").show();
  $("#settings-div").hide();

  shouldPoll = true;
  $(".sl-color-invertable").removeClass("sl-navbar-dark");
  $("#all-order-selector").addClass("sl-navbar-dark");

  $(".sl-navbar-icon.order-icon").addClass("sl-hidden");
  $(".sl-navbar-icon.order-icon-dark").removeClass("sl-hidden");
  $(".sl-navbar-icon.user-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.user-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.settings-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.settings-dark-icon").addClass("sl-hidden");

  $("#abcart-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#all-order-selector > .sl-navbar-text").addClass("navtext-color");
  $("#user-order-selector > .sl-navbar-text").removeClass("navtext-color");

  allorderpage = 0;
  $("#all-order-search").val("");
  $("#all-order-filter-selected-tag").attr("tagId", "");
  registerEventListenerForAllOrder();
}
function showUserOrder() {
  $("#all-checkout-div").hide();
  $("#user-specific-content-div").show();

  $("#all-order-div").hide();
  $("#settings-div").hide();

  $(".sl-color-invertable").removeClass("sl-navbar-dark");
  $("#user-order-selector").addClass("sl-navbar-dark");

  $(".sl-navbar-icon.order-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.order-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.user-icon").addClass("sl-hidden");
  $(".sl-navbar-icon.user-icon-dark").removeClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.settings-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.settings-dark-icon").addClass("sl-hidden");

  $("#abcart-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#user-order-selector > .sl-navbar-text").addClass("navtext-color");
  $("#all-order-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#shop-templates-div").html(
    populateTemplateUsingJSON({}, assets.templates.content, true)
  );
  registerEventListenerForUserOrder();
}
function showSettingOption() {
  console.log("...................");
  $("#settings-div").html("");
  $("#all-checkout-div").hide();
  $("#user-specific-content-div").hide();
  $("#all-order-div").hide();
  $("#settings-div").show();

  $(".sl-color-invertable").removeClass("sl-navbar-dark");
  $("#settings-selector").addClass("sl-navbar-dark");

  $(".sl-navbar-icon.order-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.order-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.user-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.user-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon").removeClass("sl-hidden");
  $(".sl-navbar-icon.cart-icon-dark").addClass("sl-hidden");
  $(".sl-navbar-icon.settings-icon").addClass("sl-hidden");
  $(".sl-navbar-icon.settings-dark-icon").removeClass("sl-hidden");

  $("#abcart-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#user-order-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#all-order-selector > .sl-navbar-text").removeClass("navtext-color");
  $("#settings-div").html(
    populateTemplateUsingJSON({}, assets.setting.content, true)
  );

  registerEventListenerForShowSetting();
}
function registerNavigationFunctions() {
  $("#abcart-selector").off("click").on("click", () => {
    $("#abcart-checkout-order-holder").html("");
    showAbCart();
    getAllAbandonedOrders();
  });
  $("#all-order-selector").off("click").on("click", () => {
    $("#order-data-holder").html("");
    showAllOrder();
    getOrdersForPhone();
  });
  $("#user-order-selector").off("click").on("click", () => {
    $("#shop-templates-div").html("");
    showUserOrder();
    loadOrders();
  });

  $("#settings-close-btn").off("click").on("click", () => {
    showSettings(false);
    showAllOrder();
    getOrdersForPhone();
  });
  $("#settings-selector").off("click").on("click", () => {
    // showSettings(false);
    showSettingOption();
  });

  $("#logout-btn").off("click").on("click", () => {
    attemptLogout();
  });

  $("#orders-btn").off("click").on("click", (event) => {
    toggleUserAbCartDiv(false);
    $("#orders-btn").data("selected", true);
    $("#ab-cart-btn").data("selected", false);
    $("#orders-btn").addClass("sl-selected-green");
    $("#ab-cart-btn").removeClass("sl-selected-green");
    $("#sl-user-order-count").removeClass("sl-hidden");
    $("#sl-user-abcart-count").addClass("sl-hidden");
    showOnlySelectedDiv(1, false);
  });
  $("#ab-cart-btn").off("click").on("click", (event) => {
    toggleUserAbCartDiv(true);
    $("#ab-cart-btn").data("selected", true);
    $("#orders-btn").data("selected", false);
    $("#orders-btn").removeClass("sl-selected-green");
    $("#ab-cart-btn").addClass("sl-selected-green");
    $("#sl-user-order-count").addClass("sl-hidden");
    $("#sl-user-abcart-count").removeClass("sl-hidden");
    showOnlySelectedDiv(1, true);
  });
  $("#reduce-count").off("click").on("click", (event) => {
    handleArrowClicks(-1);
  });
  $("#increase-count").off("click").on("click", (event) => {
    handleArrowClicks(1);
  });
  // pollOrders();
  // handle scenario
}

function pollOrders() {
  if (!interval) {
    interval = setInterval(() => {
      console.log("Polling for new Orders");

      // if this is not checked properly this might fail
      if (shouldPoll) {
        getOrdersForPhone(undefined, undefined);
      }
      /*       if ($("#all-order-selector").hasClass("sl-clickable-active")) {
            }
       */
    }, POLL_TIMEOUT);
  }
}

function isValidTemplateCreationRequest() {
  let name = $("#template-name").val();
  let text = $("#template-text").val();
  return name && name.trim() && text && text.trim();
}

function handleTemplateSubmissionButton() {
  if (isValidTemplateCreationRequest()) {
    console.log("Enabling button");
    $("#template-edit-complete").removeAttr("disabled");
    $("#template-edit-complete").removeClass("sl-button-disabled");
  } else {
    console.log("Disabling button");
    $("#template-edit-complete").attr("disabled", "true");
    $("#template-edit-complete").addClass("sl-button-disabled");
  }
}

function handleArrowClicks(addCounter) {
  let isAbCartSelected = isABCartSelected();
  let currentUserCount = parseInt(getCurrentUserCardCount(isAbCartSelected));
  let newCardCount = currentUserCount + addCounter;
  let maxCount = getMaxCardCount(isAbCartSelected);
  if (newCardCount < 1 || newCardCount > maxCount) {
    console.log("Nowhere else to go");
    return;
  }
  setCurrentCount(newCardCount, isAbCartSelected);
  showOnlySelectedDiv(newCardCount, isAbCartSelected);
}

function showOnlySelectedDiv(pos, isAbCart) {
  let divId = isAbCart
    ? ".sl-order-cards.user-specific-abcart"
    : ".sl-order-cards.user-specific-order";
  let elements = $(divId);
  for (let i = 0; i < elements.length; i++) {
    let elem = elements[i];
    let currentCard = $(elem).data("card-pos");
    if (pos == currentCard) {
      $(elem).removeClass("sl-hidden");
    } else {
      $(elem).addClass("sl-hidden");
    }
  }
}

function setCurrentCount(count, isAbCart) {
  if (isAbCart) {
    return renderCounters("#sl-user-abcart-count", count);
  }
  return renderCounters("#sl-user-order-count", count);
}

function getMaxCardCount(isAbCart) {
  if (isAbCart) {
    return $("#sl-user-abcart-count").data("max")
      ? $("#sl-user-abcart-count").data("max")
      : 0;
  }
  return $("#sl-user-order-count").data("max")
    ? $("#sl-user-order-count").data("max")
    : 0;
}

function isABCartSelected() {
  return $("#ab-cart-btn").data("selected");
}

function getCurrentUserCardCount(isAbCart) {
  if (isAbCart) {
    return $("#sl-user-abcart-count").html();
  }
  return $("#sl-user-order-count").html();
}

function toggleUserAbCartDiv(show) {
  if (show) {
    $("#user-specific-orders-div").hide();
    $("#user-specific-abcart-div").show();
  } else {
    $("#user-specific-orders-div").show();
    $("#user-specific-abcart-div").hide();
  }
}

function renderTemplateCreateDivToggle(show) {
  $("#create-new-template").data("showing-create", !show);
  $("#create-new-template").html(
    !show
      ? populateTemplateUsingJSON({}, "@{Cancel}", true)
      : populateTemplateUsingJSON({}, "@{Create New}", true)
  );
  showTemplateCreate(!show);
  $("#template-name").focus();
}

function registerQuickReplyClickListeners() {
  $(".sl-quick-reply-card").off("click").on("click", (event) => {
    let templateData = $(event.target).attr("template-content");
    sendMessageFromQuickReply(templateData);
  });
  $(".sl-quick-reply-card-text").off("click").on("click", (event) => {
    let templateData = $(event.target).parent().attr("template-content");
    sendMessageFromQuickReply(templateData);
  });
}

function sendMessageFromQuickReply(templateData) {
  if (templateData) {
    templateData = decodePayload(templateData);
  }
  sendTextMessage(templateData, (isSent) => {
    if (isSent) {
      console.log("Messsage Sent");
    } else {
      console.log("Message Not Sent");
    }
  });
}

function registerCardActionListeners() {
  $(".sl-dropdown-item")
    .off("click")
    .on("click", (event) => {
      console.log($(event.target).attr("content"));
      let element = $(event.target);
      let content = element.attr("content");
      let name = element.html();
      let selectedButton = $($(element.parent()).parent().siblings()[0]);
      let spanContent = $($(selectedButton).children()[0]);
      spanContent.html(name);
      selectedButton.attr("content", content);

      let applyButton = $(
        $($($(element.parent()).parent()).parent()).siblings()[0]
      );
      applyButton.removeAttr("disabled");
      applyButton.removeClass("sl-button-disabled");
    });

  $(".sl-template-apply-button").off("click").on("click", (event) => {
    //get Content
    // Send message
    let payload = {};
    let encodedPayload = $(event.target).data("payload");
    if (encodedPayload) {
      try {
        payload = JSON.parse(decodePayload(encodedPayload));
      } catch (error) {
        console.error(error);
      }
    }

    let content = $($($(event.target).siblings()[0]).children()[0]).attr(
      "content"
    );
    if (content) {
      content = decodePayload(content);
      sendTextMessage(renderContentFromTemplate(content, payload), () => {
        console.log("done");
      });
    } else {
      console.log("No Content Found");
    }
  });

  $(".sl-show-more-line-items")
    .off("click")
    .on("click", (event) => {
      let isMoreDisplayed = $(event.target).data("more-displayed");
      $(event.target).data("more-displayed", !isMoreDisplayed);
      $(event.target).html(isMoreDisplayed ? "Show More" : "Show Less");
      let sibling = $($(event.target).siblings()[0]);
      if (isMoreDisplayed) {
        sibling.hide();
      } else {
        sibling.show();
      }
    });
}

function clearTemplateCreateContents() {
  $("#template-name").val("");
  $("#template-text").val("");
}

function showTemplateCreate(show) {
  if (show) {
    $("#create-template-div").show();
    $("#list-template-div").hide();
  } else {
    $("#create-template-div").hide();
    $("#list-template-div").show();
  }
}

function registerForEvent() {
  window.addEventListener("message", (e) => {
    if (isPageLoadComplete) {
      onMessageHandler(e);
    } else {
      enqueueEvent(e);
    }
  });
}

function registerOrderHandler(phone) {
  $(".sl-clickable-order-div").off("click").on("click", (event) => {
    let contact = $(event.target).parents(".sl-order-cards").attr("contact");
    console.log(contact);
    if (contact) {
      window.location = "/send?phone=+" + contact;
    } else {
      handleError({ message: "No Phone Number Associated with the Order" });
    }
  });
  registerOrderCardControllersV2(phone);
}

function getNewTemplateName() {
  return $("#template-name").val();
}
function getTemplateTextAreaContent() {
  return $("#template-text").val();
}

function encodePayload(payload) {
  return btoa(unescape(encodeURIComponent(payload)));
}

function decodePayload(payload) {
  return decodeURIComponent(escape(atob(payload)));
}

////////////////////////////// API CALLS RELATED /////////////////////////////

function processDone(response, callback) {
  if (response) {
    // console.log("In Done");
    // console.log(response);
  }
  if (callback) {
    callback(response, null);
  }
}
function processFail(response, callback) {
  if (response) {
    console.log("In Fail");
    console.log(response);
  }
  handleError(response.responseJSON);
  callback(null, new Error("Unable to Get Response"));
}

function getShopDetails(callback) {
  var settings = {
    url: superlemon_account_base_url + "/account/v1/shop",
    method: "GET",
    timeout: DEFAULT_TIMEOUT,
    headers: {
      token: getApikey(),
    },
  };
  makeApiCall(settings, callback);
}

function makeApiCall(settings, callback) {
  $.ajax(settings)
    .done((response) => {
      if (response && response.shop && response.shop.featuresList && response.shop.featuresList.length && response.shop.featuresList.includes('EXTENSION')) {
        isExtensionFeatureEnabled = true
      }
      if (!isExtensionFeatureEnabled) {
        if (response && response.count > 0) response.count = 0
        if (response && response.orders && response.orders.length > 0) response.orders = []
        if (response && response.checkouts && response.checkouts.length > 0) response.checkouts = []
      }
      processDone(response, callback);
    })
    .fail((response) => {
      processFail(response, callback);
    });
}

function getOrderCount(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/order/count",
      method: "GET",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    makeApiCall(settings, callback);
  });
}
function getAbOrderCount(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/checkout/count/v2/",
      method: "GET",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
      data: {
        status: "ABANDONED",
      },
    };
    makeApiCall(settings, callback);
  });
}
function getOrders(phone, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/orders",
      method: "GET",

      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    if (phone) {
      settings.data = {
        phone: phone,
        types: "OPEN,CONFIRMED,SHIPPED,DELAYED",
        orderBy: "orderId",
      };
    } else {
      settings.url = settings.url + "/v3";
      settings.data = {
        searchBy: $("#all-order-search").val() || null,
        pageNo: allorderpage,
        orderBy: "orderId",
        pageSize: PAGESIZE,
        tagId: $("#all-order-filter-selected-tag").attr("tagId") || null,
      };
    }
    makeApiCall(settings, callback);
  });
}

function getAllAbandonedOrder(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/checkouts/v3",
      method: "GET",

      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        // token: "sat_85d1df1c0e6b4081a027d0d2ac382395",
      },
    };
    settings.data = {
      searchBy: $("#all-abandon-order-search").val() || null,
      pageNo: allabandonorderpage,
      orderBy: "checkoutId",
      pageSize: PAGESIZE,
      status: "ABANDONED",
    };
    makeApiCall(settings, callback);
  });
}

function getCheckouts(phone, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/checkouts/v3",
      method: "GET",
      data: {
        phone: phone,
        status: "ABANDONED",
      },
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    makeApiCall(settings, callback);
  });
}

function getOrderHistory(phone, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/order/history",
      method: "GET",
      data: {
        phone: phone,
      },
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };

    makeApiCall(settings, callback);
  });
}

function getTemplates(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/template",
      method: "GET",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    makeApiCall(settings, (templateResponse, error) => {
      if (templateResponse && templateResponse.templates) {
        for (let i = 0; i < templateResponse.templates.length; i++) {
          if (
            templateResponse.templates[i] &&
            templateResponse.templates[i].text
          ) {
            templateResponse.templates[i].text = encodePayload(
              templateResponse.templates[i].text
            );
          }
        }
      }

      callback(templateResponse, error);
    });
  });
}

function createTemplate(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/template",
      method: "POST",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        name: getNewTemplateName(),
        text: getTemplateTextAreaContent(),
        category: "GREETING",
      },
    };
    makeApiCall(settings, callback);
  });
}

function createTag(callback) {
  getShopId((shopId) => {
    let settings = {
      url: superlemon_messaging_base_url + "/messaging/v1/tags/" + shopId,
      method: "POST",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        name: $("#add-text-input").val().trim(),
        category: "ORDER",
      },
    };
    makeApiCall(settings, callback);
  });
}

function getAllTags(callback) {
  getShopId((shopId) => {
    let settings = {
      url: superlemon_messaging_base_url + "/messaging/v1/tags/" + shopId,
      method: "GET",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    makeApiCall(settings, callback);
  });
}

function deleteTag(tagid, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_messaging_base_url +
        "/messaging/v1/tags/" +
        shopId +
        "/" +
        tagid,
      method: "DELETE",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };
    makeApiCall(settings, callback);
  });
}

function updateTag(tagid, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_messaging_base_url +
        "/messaging/v1/tags/" +
        shopId +
        "/" +
        tagid,
      method: "PUT",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        name: $("#update-text-input").val(),
        category: "ORDER",
      },
    };

    makeApiCall(settings, callback);
  });
}

function addTagToOrder(tagid, orderid, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_messaging_base_url +
        "/messaging/v1/manual/" +
        shopId +
        "/order/" +
        orderid,
      method: "PUT",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        tagId: tagid,
      },
    };

    makeApiCall(settings, callback);
  });
}
function removeTagToOrder(tagid, orderid, callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_messaging_base_url +
        "/messaging/v1/manual/" +
        shopId +
        "/order/" +
        orderid,
      method: "DELETE",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: {
        tagId: tagid,
      },
    };

    makeApiCall(settings, callback);
  });
}

function getTranslatedData(callback) {
  getShopId((shopId) => {
    let settings = {
      url:
        superlemon_account_base_url +
        "/account/v1/shop/" +
        shopId +
        "/event/translations",
      method: "GET",
      timeout: DEFAULT_TIMEOUT,
      headers: {
        token: getApikey(),
      },
    };

    makeApiCall(settings, callback);
  });
}
////////////////////////////////////// UTILITES ////////////////////////////////

function getApikey() {
  return getFromLocalStorage(cookieKey);
}

function getFromLocalStorage(key) {
  return localStorage.getItem(key);
}

function saveInLocalStorage(key, value) {
  localStorage.setItem(key, value);
}

function removeFromLocalStorage(key) {
  localStorage.removeItem(key);
}

function isLoggedIn() {
  return getApikey() ? true : false;
}

function enqueueEvent(event) {
  eventQ.push(event);
}

function dequeEvent(onDequeue) {
  if (eventQ.length > 0) {
    if (onDequeue) {
      onDequeue(eventQ.pop());
    }
  }
}

function dequeueAll() {
  while (eventQ.length > 0) {
    dequeEvent((e) => {
      onMessageHandler(e);
    });
  }
}

///////////////////////////////////// SEND MESSAGE ////////////////////

/* function sendTextMessage(message, onSent) {
  let messageBox = document.querySelectorAll("[contenteditable='true']")[1];
  let event = document.createEvent("sendMessageEvent");
  messageBox.innerHTML = message // test it
  event.initUIEvent("input", true, true, window, 1);
  messageBox.dispatchEvent(event);
  document.getElementsByClassName("_1E0Oz")[0].click();
} */

function sendTextMessage(message, onSent) {
  let messageBox = $("[contenteditable=true]")[1];
  if (!messageBox) {
    console.log("Please Open A Chat to send message");
    if (onSent) {
      onSent(false);
    }
    return;
  }
  send_text(message,messageBox)
  if (skipPreview) {
    sendToContact(onSent);
  }
}


function send_text(text, messageBox) {
  if (!!text) {
    text = text.concat(" ")
    $(messageBox).html(text); 
    const dataTransfer = new DataTransfer();
    dataTransfer.setData('text/plain', text);
    const event = new InputEvent('input', {
      data: dataTransfer.getData('text'),
      dataTransfer: dataTransfer,
      bubbles: true
    });
    messageBox.dispatchEvent(event);
  }
}

function sendToContact(onSent) {
  let buttons = $("._1E0Oz");
  if (buttons && buttons.length > 0 && buttons[0]) {
    $(buttons[0]).click();
    if (onSent) {
      onSent(true);
    }
  } else {
    if (onSent) {
      onSent(false);
    }
  }
}

function searchNumber(number) {
  let messageBox = document.querySelectorAll("[contenteditable='true']")[0];
  let event = document.createEvent("search");
  messageBox.innerHTML = number; // test it
  event.initUIEvent("input", true, true, window, 1);
  messageBox.dispatchEvent(event);
}

function renderContentFromTemplate(template, params) {
  let keys = Object.keys(params);
  if (keys) {
    keys.forEach((key) => {
      template = template.replaceAll("{{" + key + "}}", params[key]);
    });
  }
  return template;
}

function handleError(error) {
  try {
    if (error.message) {
      showErrorMessage(error.message);
      setTimeout(() => {
        cleanErrorMessage();
      }, DEFAULT_TIMEOUT);
    }
  } catch (err) {
    console.log(err);
  }
}

function showErrorMessage(message) {
  $("#error-area").removeClass("sl-hidden");
  $("#error-area").html(message);
  $("#order-data-holder").css("height", "75vh");
  $("#abcart-checkout-order-holder").css("height", "75vh");
}

function cleanErrorMessage() {
  $("#error-area").html("");
  $("#error-area").addClass("sl-hidden");
  $("#order-data-holder").css("height", "78vh");
  $("#abcart-checkout-order-holder").css("height", "78vh");
}

// ############################## V2 ############################

function registerOrderCardControllersV2(phone) {
  $(".sl-collapse-icon")
    .off("click")
    .on("click", (event) => {
      let orderId = $(event.target).data("can-collapse");
      console.log(orderId);

      $("#is-controlled-" + orderId).addClass("sl-hidden");
      $("#can-collapse-" + orderId).addClass("sl-hidden");
      $("#can-expand-" + orderId).removeClass("sl-hidden");
    });
  $(".sl-expand-icon")
    .off("click")
    .on("click", (event) => {
      let orderId = $(event.target).data("can-expand");
      console.log("#is-controlled-" + orderId);

      $("#is-controlled-" + orderId).removeClass("sl-hidden");
      $("#can-collapse-" + orderId).removeClass("sl-hidden");
      $("#can-expand-" + orderId).addClass("sl-hidden");
    });

  console.log(localStorage.getItem("orderlayout"));
  renderVisibility(localStorage.getItem("orderlayout"));
}

function renderVisibility(layout) {
  // let gridView = true;
  if (layout === "layout-2") {
    $(".sl-collapsible").addClass("sl-hidden");
    $(".sl-expandable").removeClass("sl-hidden");
  } else {
    $(".sl-collapsible").removeClass("sl-hidden");
    $(".sl-expandable").addClass("sl-hidden");
  }
}

function renderScrollability() {
  $("order-data-holder").scroll(function () {
    if (
      $(window).scrollTop() >=
      $(document).height() - $(window).height() - 10
    ) {
      console.log("can trigger scroll");
    }
  });
}

function switchLayout() {
  let temp = localStorage.getItem("orderlayout");
  if (temp === "layout-1") {
    $("#layout-1").addClass("orderlayout-selected");
    $("#layout-2").addClass("orderlayout-notselected");
    $("#layout-1").removeClass("orderlayout-notselected");
  } else if (temp === "layout-2") {
    $("#layout-2").addClass("orderlayout-selected");
    $("#layout-2").removeClass("orderlayout-notselected");
    $("#layout-1").addClass("orderlayout-notselected");
  }
}

function registerEventListenerForOrderLayout() {}

function renderTagList(temptagss) {
  $("#tag-list").html("");
  for (let i = 1; i <= temptagss.length; i++) {
    let temp = { ...temptagss[i - 1] };
    if (i === 1) {
      temp["border-class"] = "rounded-t-xl";
    } else if (i === temptagss.length) {
      temp["border-class"] = "rounded-b-xl";
    } else {
      temp["border-class"] = "";
    }

    $("#tag-list").append(
      populateTemplateUsingJSON(temp, assets.tagItem.content, true)
    );
  }

  temptagss.forEach(function (el) {
    console.log(el);
    $("#tag-delete-btn-" + el.id).click(function (e) {
      let id = $(this).attr("data-id");
      deleteTag(el.id, () => {
        getAllTags((r) => {
          renderTagList(r.tags);
        });
      });
    });
  });

  temptagss.forEach(function (el) {
    $("#tag-edit-btn-" + el.id).click(function (e) {
      console.log("--------------------");
      let id = $(this).attr("data-id");
      let text = $(this).attr("data-text");
      $("#add-tag").addClass("sl-hidden");
      $("#tag-list").addClass("sl-hidden");
      $("#update-tag").removeClass("sl-hidden");
      $("#update-text-input").val(text);
      $("#update-tag-btn").attr("data-update-tagid", el.id);
    });
  });
}

function registerEventListenerForAllOrder() {
  $("#all-order-filter")
    .off("mouseenter")
    .mouseenter(function () {
      $("#all-order-filter").addClass("addbgcolor");
      $("#all-order-filter > div > div  > svg").css({ color: "white" });
    });

  $("#all-order-filter")
    .off("mouseleave")
    .mouseleave(function () {
      $("#all-order-filter").removeClass("addbgcolor");
      $("#all-order-filter > div > div  > svg").css({ color: "#6b7280" });
    });
  var delayTimer;

  $("#all-order-search")
    .off("input")
    .on("input", function () {
      clearTimeout(delayTimer);
      delayTimer = setTimeout(function () {
        $("#order-data-holder").html("");
        allorderpage = 0;
        getOrdersForPhone();
      }, 500);
    });

  getAllTags((r) => {
    renderApplicableTag(r.tags, "#all-order-filter-tag", "forsearch");
  });
  $("#order-data-holder")
    .off("scroll")
    .on("scroll", function () {
      if (
        $(this)[0].scrollHeight - $(this).scrollTop() - $(this).innerHeight() <
          -5.3 &&
        $("#order-data-holder").html() !== ""
      ) {
        if (isMoreAllOrderAvailble) {
          allorderpage++;
          getOrdersForPhone();
        }
      }
    });
}

function registerEventListenerForAllAbandonedOrder() {
  var delayTimer;

  $("#all-abandon-order-search")
    .off("input")
    .on("input", function () {
      clearTimeout(delayTimer);
      delayTimer = setTimeout(function () {
        $("#abcart-checkout-order-holder").html("");
        allabandonorderpage = 0;
        getAllAbandonedOrders();
      }, 500);
    });

  $("#abcart-checkout-order-holder")
    .off("scroll")
    .on("scroll", function () {
      if (
        $(this)[0].scrollHeight - $(this).scrollTop() - $(this).innerHeight() <
          -5.3 &&
        $("#abcart-checkout-order-holder").html() !== ""
      ) {
        if (isMoreABOrderAvailble) {
          allabandonorderpage++;
          getAllAbandonedOrders();
        }
      }
    });
}
function registerEventListenerForUserOrder() {
  getTemplates((response) => {
    renderTemplates(response.templates);
    registerQuickReplyClickListeners();
    $("#create-new-template").off("click").on("click", (event) => {
      let showingCreate = $(event.target).data("showing-create");
      renderTemplateCreateDivToggle(showingCreate);
    });
  });

  $("#template-name").off("input").on("input", (event) => {
    handleTemplateSubmissionButton();
  });

  $("#template-text").off("input").on("input", (event) => {
    handleTemplateSubmissionButton();
  });

  $("#template-edit-complete").off("click").on("click", () => {
    if (isValidTemplateCreationRequest()) {
      createTemplate(() => {
        clearTemplateCreateContents();
        renderTemplateCreateDivToggle(true);
        loadOrders();
      });
    } else {
      handleError({
        message: "Please Enter Template Name and Text Before Submitting",
      });
      console.log("Disabling button");
      $("#template-edit-complete").attr("disabled", "true");
      $("#template-edit-complete").addClass("sl-button-disabled");
    }
  });
  $("#template-edit-cancel").off("click").on("click", () => {
    clearTemplateCreateContents();
    showTemplateCreate(false);
  });
}
function registerEventListenerForShowSetting() {
  const languageData = JSON.parse(localStorage.getItem("landata"));
  const languages = Object.keys(languageData);
  for (const l of languages) {
    $("#language-list").append(
      populateTemplateUsingJSON(
        { languageitem: l },
        assets.languageItem.content,
        false
      )
    );
  }
  let templanguage = localStorage.getItem("selected-language");
  if (!templanguage) {
    localStorage.setItem("selected-language", "English");
    $("#language-selector > p").html("English");
  } else {
    $("#language-selector > p").html(templanguage);
  }
  $("#language-selector").click(function () {
    if ($("#language-list").hasClass("sl-hidden")) {
      $("#language-list").removeClass("sl-hidden");
    } else {
      $("#language-list").addClass("sl-hidden");
    }
  });
  $("#language-list").on("mouseleave", function (event) {
    $("#language-list").addClass("sl-hidden");
  });
  $("#language-list")
    .off("click")
    .on("click", "p", function (event) {
      $("#language-list").addClass("sl-hidden");
      localStorage.setItem(
        "selected-language",
        $(event.target).attr("data-lan")
      );
      $("#language-selector > p").html($(event.target).attr("data-lan"));

      $(".dynamic-title").each(function (i, l) {
        const languageData = JSON.parse(localStorage.getItem("landata"));
        l.innerHTML =
        languageData[$(event.target).attr("data-lan")][$(l).attr("data-content")];
      });
      showSettingOption();
    });

  let temp = localStorage.getItem("orderlayout");
  if (temp) {
    switchLayout();
  } else {
    localStorage.setItem("orderlayout", "layout-1");
    switchLayout();
  }

  $("#layout-1").click(function () {
    localStorage.setItem("orderlayout", "layout-1");
    switchLayout();
  });
  $("#layout-2").click(function () {
    localStorage.setItem("orderlayout", "layout-2");
    switchLayout();
  });

  getAllTags((r) => {
    renderTagList(r.tags);
  });

  $("#create-new-tag").click(function () {
    $("#add-tag").removeClass("sl-hidden");
    $("#tag-list").addClass("sl-hidden");
    $("#add-tag-error-msg").addClass("sl-hidden");
    $("#update-tag-error-msg").addClass("sl-hidden");
  });

  $("#cancel-tag-btn").click(function () {
    $("#add-tag").addClass("sl-hidden");
    $("#tag-list").removeClass("sl-hidden");
    $("#add-tag-error-msg").addClass("sl-hidden");
    $("#add-text-input").val("");
  });

  $("#update-cancel-tag-btn").click(function () {
    $("#update-tag").addClass("sl-hidden");
    $("#tag-list").removeClass("sl-hidden");
    $("#update-tag-error-msg").addClass("sl-hidden");
  });

  $("#add-tag-btn").click(function (e) {
    let value = $("#add-text-input").val();
    if (value.length > 40) {
      $("#add-tag-error-msg").html("Maximum 40 Characters Allowed");
      $("#add-tag-error-msg").removeClass("sl-hidden");
      setTimeout(function () {
        $("#add-tag-error-msg").addClass("sl-hidden");
      }, 5000);
      return;
    }
    if (value && value.trim()) {
      createTag(() => {
        $("#add-text-input").val("");
        $("#add-tag").addClass("sl-hidden");
        $("#tag-list").removeClass("sl-hidden");
        getAllTags((r) => {
          renderTagList(r.tags);
        });
      });
    } else {
      $("#add-tag-error-msg").html("Enter Valid Tag Name");
      $("#add-tag-error-msg").removeClass("sl-hidden");
      setTimeout(function () {
        $("#add-tag-error-msg").addClass("sl-hidden");
      }, 5000);
    }
  });

  $("#update-tag-btn").click(function (e) {
    let value = $("#update-text-input").val();
    let id = $("#update-tag-btn").attr("data-update-tagid");
    let prevVal = $("#tag-edit-btn-" + id).attr("data-text");
    if (prevVal === value) {
      $("#update-tag").addClass("sl-hidden");
      $("#tag-list").removeClass("sl-hidden");
      return;
    }
    if (value.length > 40) {
      $("#update-tag-error-msg").html("Maximum 40 Characters Allowed");
      $("#update-tag-error-msg").removeClass("sl-hidden");
      setTimeout(function () {
        $("#update-tag-error-msg").addClass("sl-hidden");
      }, 5000);
      return;
    }
    if (value && value.trim()) {
      updateTag(id, () => {
        getAllTags((r) => {
          $("#update-tag").addClass("sl-hidden");
          $("#tag-list").removeClass("sl-hidden");
          renderTagList(r.tags);
        });
      });
    } else {
      $("#update-tag-error-msg").html("Enter Valid Tag Name");

      $("#update-tag-error-msg").removeClass("sl-hidden");
      setTimeout(function () {
        $("#update-tag-error-msg").addClass("sl-hidden");
      }, 5000);
    }
  });
}