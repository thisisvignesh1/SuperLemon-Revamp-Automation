initMutation();
console.log("Attempt Show Details initated");
attemptShowDetailsOnLoad(() => {
  console.log("Attemp Show Details Done");
});

function getKey(dom) {
  let keys = Object.keys(dom);
  for (let i = 0; i < keys.length; i++) {
    if (keys[i].startsWith("__react")) {
      console.log(keys[i]);
      return keys[i];
    }
  }
}

function FindReact(dom, traverseUp = 0) {
  let key = getKey(dom);
  const domFiber = dom[key];
  if (domFiber == null) return null;
  // react <16
  if (domFiber._currentElement) {
    let compFiber = domFiber._currentElement._owner;
    for (let i = 0; i < traverseUp; i++) {
      compFiber = compFiber._currentElement._owner;
    }
    return compFiber._instance;
  }
  // react 16+
  const GetCompFiber = (fiber) => {
    //return fiber._debugOwner; // this also works, but is __DEV__ only
    let parentFiber = fiber.return;
    while (typeof parentFiber.type == "string") {
      parentFiber = parentFiber.return;
    }
    return parentFiber;
  };
  let compFiber = GetCompFiber(domFiber);
  for (let i = 0; i < traverseUp; i++) {
    compFiber = GetCompFiber(compFiber);
  }
  return compFiber.stateNode;
}

function mutationHasId(mutation) {
  if (mutation.addedNodes.length) {
    for (let i = 0; i < mutation.addedNodes.length; i++) {
      if (mutation.addedNodes[i].id == "main") {
        return true;
      }
    }
  }
  return false;
}

function getDateFromReactNodes() {
  try {

    //console.log(FindReact(document.querySelectorAll("header")[1]).props);
    let prop = FindReactV2(document.querySelector("#main"), 'chat');

    if (!prop) {
      FindReactV2(document.querySelector("body"), 'chat');
    }
    if (!prop) {
      FindReact(document.querySelectorAll("header")[1]).props;
    }
    console.log(prop);
    //console.log("%cChat changed New !!", "font-size:x-large");
    var WAName = prop.chat.contact.__x_pushname;
    const ContactName = prop.chat.contact.__x_formattedName;
    const phone = prop.chat.contact.__x_id.user;
    const Greetings = "";
    const serialized = prop.chat.id._serialized;
    return {
      WAName,
      ContactName,
      Greetings,
      phone,
      serialized,
    };
  } catch (err) {
    console.log("Unable to find number from react node");
  }
}

function getDataFromImageUrl() {
  try {
    let content = document.querySelectorAll("header")[1].children[0].children[0].children[1].getAttribute('src');
    content = decodeURIComponent(content);
    return { "phone": content.substring(content.indexOf("&u=") + 3, content.indexOf("@c.us&")) };
  } catch (err) {
    console.log("phone not found from url");
  }
}



function initMutation() {
  var observer = new MutationObserver((mutations) => {
    for (var mutation of mutations) {
      // console.log(mutation);
      if (mutationHasId(mutation)) {
        let data = getDateFromReactNodes();
        /*    if (!data) {
             data = getDataFromImageUrl();
             console.log("user found", data);
           } */
        if (data) {
          window.postMessage({ type: "user-change", user: data }, "*");
        }

      }
    }
  });
  console.log("query selector ===>", document.querySelector("#app"));
  var doc_query = document.querySelector("#app");
  if (!doc_query) {
    window.setTimeout(initMutation, 500);
    return;
  } else {
    observer.observe(document.querySelector("#app"), {
      attributes: false,
      childList: true,
      subtree: true,
    });
  }
}

function onChatLoaded(onComplete) {
  //console.log(mutation);
  if (document.querySelector(".sl-main-div")) {
    //console.log(FindReact(document.querySelectorAll("header")[1]).props);
    let headerNodes = document.querySelectorAll("header");
    if (!headerNodes || headerNodes.length < 2) {
      return onComplete(false);
    }
    let reactNode = FindReact(headerNodes[1]);
    console.log("Data Found Triggering Request");
    if (!reactNode) {
      return onComplete(false);
    }
    let prop = reactNode.props;
    // console.log("%cChat changed New !!", "font-size:x-large");
    if (!prop) {
      return onComplete(false);
    }
    var WAName = prop.chat.contact.__x_pushname;
    const ContactName = prop.chat.contact.__x_formattedName;
    const phone = prop.chat.contact.__x_id.user;
    const Greetings = "";
    const serialized = prop.chat.id._serialized;
    const data = {
      WAName,
      ContactName,
      Greetings,
      phone,
      serialized,
    };

    window.postMessage({ type: "user-change", user: data }, "*");
    return onComplete(true);
  }
}

function attemptShowDetailsOnLoad(onLoadDone) {
  let interval = setInterval(() => {
    console.log("attempt New Chat Load");
    onChatLoaded((state) => {
      if (state) {
        console.log("New Chat Load Completed");
      } else {
        console.log("New Chat Not Loaded");
      }
      clearInterval(interval);
      if (onLoadDone) {
        onLoadDone(state);
      }
    });
  }, 2000);
}



function FindReactV2(dom, propTofind) {
  let key = getKey(dom);
  const domFiber = dom[key];
  return processDOM(domFiber, propTofind);
}

function processDOM(domFiber, propTofind) {
  if (domFiber == null) return null;
  // react <16
  if (domFiber.pendingProps && domFiber.pendingProps[propTofind]) {
    return domFiber.pendingProps;
  } else if (domFiber.child) {
    //need to go multi level
    return processDOM(domFiber.child, propTofind);
  }
  return null;
}
