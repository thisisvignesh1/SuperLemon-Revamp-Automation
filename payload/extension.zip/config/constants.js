let superlemon_account_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_messaging_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_event_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_domain = "gupshup.io";
let whatsapp_base_url = "https://web.whatsapp.com";
let whatsapp_domain = "whatsapp.com";
let cookieKey = "access_token";
let storeClientKey = "sl-store-client";

// Don't remove below comment it required to run load env sh
// ---------------- End of env constant ---------------