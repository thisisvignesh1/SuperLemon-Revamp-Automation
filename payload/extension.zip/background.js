let superlemon_account_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_messaging_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_event_base_url = "https://qa-api-ss-integration.gupshup.io";
let superlemon_domain = "gupshup.io";
let whatsapp_base_url = "https://web.whatsapp.com";
let whatsapp_domain = "whatsapp.com";
let cookieKey = "access_token";
let storeClientKey = "sl-store-client";

// Don't remove below comment it required to run load env sh
// ---------------- End of env constant ---------------

// DO NOT WRITE ANYTHING ON ABOVE THIS LINE OTHERWISE IT WILL REPLACE ON ENV LOAD

let connectedPort;

registerListner();

function registerListner() {
  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    sendResponse();
    handleEvents(message);
  });

  chrome.runtime.onConnect.addListener(function (port) {
    //if (port.name === "login-state") {
    connectedPort = port;
    port.onMessage.addListener(function (msg) {
      handleEvents(msg, true);
    });
    //}
  });
}

function handleEvents(message, fromPort) {
  if (message && message.type) {
    switch (message.type) {
      case "login-request":
        performLoginAction(message.content, (status) => {
          triggerEvent(message.type, status, fromPort);
        });
        break;
      case "logout-request":
        performLogOutAction(message.content, (status) => {
          triggerEvent(message.type, status, fromPort);
        });
        break;
      case "login-query":
        if (message.checkInterval) {
          checkPopupCloseAndLogin(message, fromPort)
        } else {
          checkLogin((status) => {
            triggerEvent(message.type, status, fromPort);
          });
        }
        break;
    }
  }
}

function triggerEvent(eventType, status, fromPort) {
  if (!fromPort) {
    chrome.runtime.sendMessage(
      { type: eventType, status: status },
      (response) => { }
    );
  }
  if (connectedPort) {
    connectedPort.postMessage({ type: eventType, status: status });
  }
}

function checkPopupCloseAndLogin(message, fromPort) {
  var loginInterval = setInterval(() => {
    checkLogin((isLoggedIn) => {
      if (isLoggedIn) {
        clearInterval(loginInterval)
        triggerEvent(message.type, isLoggedIn, fromPort);
      }
    })
  }, 1000);
}

function performLoginAction(data, callback) {
  checkLogin(callback);
}

function performLogOutAction(data, callback) {
  //alert("Logout Request" + JSON.stringify(data));
  logout(callback);
}

function checkLogin(callback) {
  isLoggedIn((isIn) => {
    if (!isIn) {
      getCookie(superlemon_account_base_url, cookieKey, (value) => {
        if (value) {
          saveInLocalStorage(
            cookieKey,
            value,
            whatsapp_domain,
            whatsapp_base_url,
            () => {
              if (callback) {
                callback(true);
              }
            }
          );
        } else {
          if (callback) {
            callback(false);
          }
        }
      });
    } else {
      if (callback) {
        callback(true);
      }
    }
  });
}

function isLoggedIn(onComplete) {
  getFromLocalStorage(cookieKey, (value) => {
    if (onComplete) {
      onComplete(value ? true : false);
    }
  });
}

function getFromLocalStorage(key, onLoad) {
  chrome.storage.local.get([key], function (result) {
    if (onLoad) {
      onLoad(result ? result[key] : null);
    }
  });
}

function saveInLocalStorage(key, value, domain, url, onComplete) {
  let data = {};
  data[key] = value;
  console.log("saving " + JSON.stringify(data));
  chrome.storage.local.set(data, function () {
    if (onComplete) {
      onComplete();
    }
  });
}

function getCookie(url, id, callback) {
  chrome.cookies.get({ url: url, name: id }, function (cookie) {
    if (callback) {
      callback(cookie ? cookie.value : null);
    }
  });
}

function removeCookie(url, id, callback) {
  chrome.cookies.remove({ url: url, name: id }, function () {
    if (callback) {
      callback();
    }
  });
}

function cleanLocalStorage(onDone) {
  chrome.storage.local.clear(() => {
    if (onDone) {
      onDone();
    }
  });
}

function logout(onLogout) {
  cleanLocalStorage(() => {
    removeCookie(superlemon_account_base_url, cookieKey, () => {
      if (onLogout) {
        onLogout(true);
      }
    });
  });
}
